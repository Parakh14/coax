module Semantic
  module Ui
    module Sass
      VERSION = "2.4.2.0"
      SEMANTIC_UI_SHA = '3989d7243c514f9018a55eb53cb34daf3bbf5a26'
    end
  end
end
