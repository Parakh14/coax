# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Dummy::Application.config.secret_key_base = 'c0f69bf52406eb5adfd93802b5338525016198c97832b293e77c295ed2021d0ed7d480a0d0567b6a0abd8894a1793574394b2744600a67f9c1570b65905ba250'
